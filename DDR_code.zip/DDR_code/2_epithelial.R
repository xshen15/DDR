gc()
scRNA=readRDS('scRNA_celltype.rds')
library(Seurat)
# 间质细胞的NMF和分析
# 取出tumor的间质
table(scRNA@meta.data$celltype)
scRNA_T=subset(scRNA, orig.ident=='Tumor')
scRNA_fibro=subset(scRNA_T,celltype %in% 'Epithelial cells')
dim(scRNA_fibro)

gene=read.csv('DDR_genes.csv',header = F)
gene=as.matrix(gene)
gene=as.vector(gene)

# DDR
scRNA_fibro$id=colnames(scRNA_fibro)
scRNA_fibro_aa=scRNA_fibro[rownames(scRNA_fibro) %in% gene,]

df <- scRNA_fibro_aa@assays$RNA@data
df=as.data.frame(df)

df <- df[rowMeans(df) !=0,  ]
df <- df[,colMeans(df) !=0 ]

## 一点没表达的细胞去除
scRNA_fibro=subset(scRNA_fibro,id %in% colnames(df))

library(NMF)
res <- nmf(df, 10, method = "snmf/r", seed = 'nndsvd')

## NMF结果返回suerat对象
scRNA_fibro@reductions$nmf <- scRNA_fibro@reductions$pca
scRNA_fibro@reductions$nmf@cell.embeddings <- t(coef(res))    
scRNA_fibro@reductions$nmf@feature.loadings <- basis(res)  

## 使用nmf的分解结果降维聚类!重要
set.seed(999)

scRNA_fibro.nmf <- RunUMAP(scRNA_fibro, reduction = 'nmf', dims = 1:10) 
scRNA_fibro.nmf <- FindNeighbors(scRNA_fibro.nmf,reduction = 'nmf', dims = 1:10)
scRNA_fibro.nmf <- FindClusters(scRNA_fibro.nmf)
scRNA_fibro.nmf$NMF_cluster=scRNA_fibro.nmf$seurat_clusters

## 结果可视化  
DimPlot(scRNA_fibro.nmf, label = T,cols=c('#313c63','#b42e20','#ebc03e','#377b4c',
                                          '#7bc7cd','#5d84a4','#dadada')) 

## 每个cluster的特征基因
df=FindAllMarkers(scRNA_fibro.nmf,logfc.threshold = 0.5,only.pos = T)

#write.csv(df,file ='deg_cancer2.csv',quote=F)

## 画图看一看
FeaturePlot(scRNA_fibro.nmf,features = 'UBE2N')  #UBE2N是0群CAF的特征基因
FeaturePlot(scRNA_fibro.nmf,features = 'CDK4') #CDK4是1群CAF的特征基因
FeaturePlot(scRNA_fibro.nmf,features = 'PARP4') #PARP4是4群CAF的特征基因
FeaturePlot(scRNA_fibro.nmf,features = 'HMGB2') #CDK4是5群CAF的特征基因
FeaturePlot(scRNA_fibro.nmf,features = 'HMGB1') #HMGB1是5群CAF的特征基因
FeaturePlot(scRNA_fibro.nmf,features = 'TDG') #TDG是6群CAF的特征基因
DoHeatmap(scRNA_fibro.nmf,features = rownames(df),assay = 'RNA',slot = 'count')



## 拟时序分析
library(Seurat)
#没有monocle要先安装 BiocManager::install()
#BiocManager::install('monocle',update = F,ask = F)

library(BiocGenerics)
library(monocle)
library(tidyverse)
library(patchwork)
data=as.matrix(scRNA_fibro.nmf@assays$RNA@counts)

data <- as(data, 'sparseMatrix')
pd <- new('AnnotatedDataFrame', data = scRNA_fibro.nmf@meta.data)
fData <- data.frame(gene_short_name = row.names(data), row.names = row.names(data))
fd <- new('AnnotatedDataFrame', data = fData)
## 以下代码一律不得修改
mycds <- newCellDataSet(data,
                        phenoData = pd,
                        featureData = fd,
                        expressionFamily = negbinomial.size())

mycds <- estimateSizeFactors(mycds)
mycds <- estimateDispersions(mycds, cores=4, relative_expr = TRUE)

##使用monocle选择的高变基因，不修改
disp_table <- dispersionTable(mycds)
disp.genes <- subset(disp_table, mean_expression >= 0.1 & dispersion_empirical >= 1 * dispersion_fit)$gene_id
mycds <- setOrderingFilter(mycds, disp.genes)
plot_ordering_genes(mycds)



#降维
mycds <- reduceDimension(mycds, max_components = 2, method = 'DDRTree')
#排序
mycds <- orderCells(mycds)

ss=intersect(gene,rownames(scRNA_fibro.nmf))
dev.off()
my_pseudotime_cluster <- plot_pseudotime_heatmap(mycds[ss,],
                                                 # num_clusters = 2, # add_annotation_col = ac,
                                                 show_rownames = TRUE,
                                                 return_heatmap = TRUE)

my_pseudotime_cluster 


#State轨迹分布图
plot1 <- plot_cell_trajectory(mycds, color_by = "State")
plot1

plot4 <- plot_cell_trajectory(mycds, color_by = "NMF_cluster")
plot4

##合并出图
plotc <- plot1|plot4
plotc

##绘制拟时序的tsne或umap
library(monocle)
library(Seurat)
library(ggplot2)
#查看umap的位置信息
head(scRNA_fibro.nmf@reductions$umap@cell.embeddings)

#查看cell的Pseudotime 信息
head(mycds@phenoData@data)
#将Pseudotime信息添加到pbmc的meta.data中
scRNA_fibro.nmf@meta.data$Pseudotime <- mycds@phenoData@data$Pseudotime 
head(scRNA_fibro.nmf@meta.data)
#划分pseudotime
#将Pseudotime分类
p3 <- plot_cell_trajectory(mycds, color_by = "Pseudotime")+
  scale_color_gradientn(values = seq(0,1,0.2),
                        colours = c('blue','cyan','green','yellow','orange','red'))
p3
#Pseudotime映射到umap图
#提取位置和Pseudotime信息
mydata<- FetchData(scRNA_fibro.nmf,vars = c("UMAP_1","UMAP_2","Pseudotime"))

p <- ggplot(mydata,aes(x = UMAP_1,y =UMAP_2,colour = Pseudotime))+
  geom_point(size = 1)+
  scale_color_gradientn(values = seq(0,1,0.2),
                        colours = c('blue','cyan','green','yellow','orange','red'))

p4 <- p + theme_bw() + theme(panel.border = element_blank(), 
                             panel.grid.major = element_blank(),
                             panel.grid.minor = element_blank(), 
                             axis.line = element_line(colour = "black"))
p4
p3 / p4
## 定义新的细胞亚群！
NMF_celltype <- c('UBE2N+Epi-C1','CDK4+Epi-C2','Non-DRR-Epi-C6','Non-DRR-Epi-C6',
                  'PARP4+Epi-C3','HMGB2+Epi-C4','TDG+Epi-C5')
Idents(scRNA_fibro.nmf) <- scRNA_fibro.nmf@meta.data$NMF_cluster
names(NMF_celltype) <- levels(scRNA_fibro.nmf)
scRNA_fibro.nmf<- RenameIdents(scRNA_fibro.nmf, NMF_celltype)
scRNA_fibro.nmf@meta.data$NMF_celltype <- Idents(scRNA_fibro.nmf)
Idents(scRNA_fibro.nmf)=scRNA_fibro.nmf@meta.data$NMF_celltype

DimPlot(scRNA_fibro.nmf,group.by = 'NMF_celltype',label = T,cols=c('#313c63','#b42e20','#ebc03e','#377b4c',
                                                           '#7bc7cd','#5d84a4'))

FeaturePlot(scRNA_fibro.nmf,features = 'CDK4')
saveRDS(scRNA_fibro.nmf,file ='scRNA_Epi_NMF.RDS')


########## 细胞通讯(间质和其他所有细胞）#################################
scRNA_fibro.nmf=readRDS('scRNA_Epi_NMF.RDS')
library(Seurat)
scRNA_chat <-subset(scRNA, orig.ident =='Tumor')
table(scRNA@meta.data$celltype)
Idents(scRNA_chat)
scRNA_chat2 <-subset(scRNA_chat, idents=c('Undetermined','Epithelial cells'),invert=T)

table(scRNA_chat2@meta.data$celltype)
# 赋一列
scRNA_chat2$NMF_celltype=scRNA_chat2$celltype
scRNA_chat=merge(scRNA_chat2,scRNA_fibro.nmf)


meta =scRNA_chat@meta.data # a dataframe with rownames containing cell mata data

data_input <- as.matrix(scRNA_chat@assays$RNA@data)
#data_input=data_input[,rownames(meta)]
identical(colnames(data_input),rownames(meta))

library(CellChat)
cellchat <- createCellChat(object = data_input, meta = meta, group.by = "NMF_celltype")

CellChatDB <- CellChatDB.human 
groupSize <- as.numeric(table(cellchat@idents))
CellChatDB.use <- subsetDB(CellChatDB, search = "Secreted Signaling") 
cellchat@DB <- CellChatDB.use 

dplyr::glimpse(CellChatDB$interaction)##配体-受体分析
# 提取数据库支持的数据子集
cellchat <- subsetData(cellchat)
# 识别过表达基因
cellchat <- identifyOverExpressedGenes(cellchat)
# 识别配体-受体对
cellchat <- identifyOverExpressedInteractions(cellchat)
# 将配体、受体投射到PPI网络
cellchat <- projectData(cellchat, PPI.human)
unique(cellchat@idents)

cellchat <- computeCommunProb(cellchat)

# Filter out the cell-cell communication if there are only few number of cells in certain cell groups
cellchat <- filterCommunication(cellchat, min.cells = 10)
cellchat <- computeCommunProbPathway(cellchat)

df.net<- subsetCommunication(cellchat)

cellchat <- aggregateNet(cellchat)
groupSize <- as.numeric(table(cellchat@idents))

##时常deff.off!!!!
dev.off()
table(cellchat@meta$NMF_celltype)
netVisual_circle(cellchat@net$count, vertex.weight = groupSize, 
                 weight.scale = T, label.edge= T,
                 sources.use = c('UBE2N+Epi-C1','CDK4+Epi-C2','Non-DRR-Epi-C6',
                                 'PARP4+Epi-C3','HMGB2+Epi-C4','TDG+Epi-C5'), 
                 targets.use = c('B cells','T cells','Endothelial','Fibroblasts',
                                 'Mast_cells','Monoctyes'),
                 title.name = "Number of interactions")
dev.off()

netVisual_circle(cellchat@net$weight, vertex.weight = groupSize, 
                 weight.scale = T, label.edge= T, 
                 sources.use = c('UBE2N+Epi-C1','CDK4+Epi-C2','Non-DRR-Epi-C6',
                                 'PARP4+Epi-C3','HMGB2+Epi-C4','TDG+Epi-C5'), 
                 targets.use = c('B cells','T cells','Endothelial','Fibroblasts',
                                 'Mast_cells','Monoctyes'),
                 title.name = "Interaction weights/strength")
dev.off()




### 转录因子
#####SCENIC#####
scRNAsub=readRDS('scRNA_Epi_NMF.RDS')

library(SCENIC)
library(Seurat)

## 内存不够控制细胞数目,这里CAF只有100多个，所以不挑
#set.seed(123456)
#a=sample(1:ncol(scRNAsub),200)
#scRNAsub=scRNAsub[,a]

exprMat <- as.matrix(scRNAsub@assays$RNA@counts)
cellInfo <-scRNAsub@meta.data

# 进入子文件夹
setwd("SCENIC") 

Idents(scRNAsub)=scRNAsub$NMF_celltype

### Initialize settings
dir.create("int")
saveRDS(cellInfo, file="int/cellInfo.Rds")

Idents(scRNAsub) <- "NMF_cluster"
# Color to assign to the variables (same format as for NMF::aheatmap)

# 人！！！！
org='hgnc'


dbDir="D:/single_cell_project/HRD/CRC_HRD/SCENIC/SCENIC2" # RcisTarget databases location

myDatasetTitle="SCENIC Challenge" # choose a name for your analysis
data(defaultDbNames)
dbs <- defaultDbNames[[org]]
dbs
getwd()
scenicOptions <- initializeScenic(org=org,dbDir=dbDir,dbs=dbs)

scenicOptions@inputDatasetInfo$cellInfo <- "cellInfo.Rds"
scenicOptions@inputDatasetInfo$colVars <- "colVars.Rds"

# 节省内存，我们只取一个基因组文件
# 人：用下面！！！！！！！！！
scenicOptions@settings$dbs <- c("mm9-5kb-mc8nr" = "hg19-tss-centered-10kb-7species.mc9nr.feather")
scenicOptions@settings$db_mcVersion <- "v8"
saveRDS(scenicOptions, file="scenicOptions.Rds") 

#Gene filter: Filter by the number of cells in which the gene is detected (minCountsPerGene, by default 6 UMI counts across all samples)
# and by the number of cells in which the gene is detected (minSamples, by default 1% of the cells)
# 尽可能减少基因数目
# 如果需要更多基因，0.1调成0.05或0.01
genesKept <- geneFiltering(exprMat, scenicOptions=scenicOptions,minCountsPerGene=3*.01*ncol(exprMat),minSamples=ncol(exprMat)*.4)

exprMat_filtered <- exprMat[genesKept,]
dim(exprMat_filtered)

#calculating correlation
runCorrelation(exprMat_filtered, scenicOptions)

#GENIE3: infer potential transcription factor targets based on the expression data
exprMat_filtered <- log2(exprMat_filtered+1) 


# 等待较久的一步，纳入基因和细胞越多，等待越久，此处只用了1000多基因，200个细胞
# 对应的TF也只有100多个了，其实有1000多个TF，如果是性能好的计算机可以考虑前面0.1调成0.05或0.01
library(RcisTarget)
data(motifAnnotations_hgnc_v8) 

runGenie3(exprMat_filtered, scenicOptions)

scenicOptions@settings$verbose <- TRUE
scenicOptions@settings$nCores <- 1
scenicOptions@settings$seed <- 123
 

exprMat_log <- log2(exprMat+1)
dim(exprMat)

#scenicOptions@settings$dbs <- scenicOptions@settings$dbs["10kb"] # For toy run
scenicOptions <- runSCENIC_1_coexNetwork2modules(scenicOptions)
saveRDS(scenicOptions, file="scenicOptions.Rds") 

# step2容易崩，节省内存只看top50
gc()
getwd()
scenicOptions=readRDS('scenicOptions.Rds')

library(RcisTarget)
data(motifAnnotations_hgnc) 
scenicOptions <-runSCENIC_2_createRegulons(scenicOptions, coexMethod=c("top5perTarget"))#** Only for toy run!!
#scenicOptions <- runSCENIC_2_createRegulons(scenicOptions) 
saveRDS(scenicOptions, file="scenicOptions.Rds")

library(foreach)
scenicOptions <- readRDS("scenicOptions.Rds")
scenicOptions <- runSCENIC_3_scoreCells(scenicOptions, exprMat_log)
saveRDS(scenicOptions, file="scenicOptions_Epi.Rds") # To save status

#============================================

#下次可以直接读取他,我们已经越过最耗时间的步骤
# 如果经常报错，不要重新readRDS和load，应不间断运行

setwd("./Epi/") 
getwd()
scenicOptions <- readRDS("scenicOptions_Epi.Rds")

scenicOptions@settings$seed <- 123 # same seed for all of them

#Binarizing the network

runSCENIC_4_aucell_binarize(scenicOptions)

aucell_regulonAUC <- loadInt(scenicOptions, "aucell_regulonAUC")
aucell_regulonAUC
aucell_regulonAUC.t <- t(aucell_regulonAUC@assays@data$AUC)
colnames(aucell_regulonAUC.t) <- gsub(" ", "_", colnames(aucell_regulonAUC.t))
rownames(aucell_regulonAUC.t) <- gsub("[.]", "-", rownames(aucell_regulonAUC.t))

fibro.scenic <- scRNAsub
# 结果导入endo.scenic
fibro.scenic@meta.data <- cbind(fibro.scenic@meta.data, aucell_regulonAUC.t[rownames(fibro.scenic@meta.data),])
dev.off()
DimPlot(fibro.scenic, reduction = "umap")
# 找6个
FeaturePlot(fibro.scenic, reduction = "umap", features = colnames(fibro.scenic@meta.data)[20:27], cols = c("yellow", "red"))

#Regulon scores heatmap 热图
Idents(fibro.scenic)=fibro.scenic$NMF_celltype
cells.ord.cluster <- fibro.scenic@active.ident
cells.ord.cluster<- cells.ord.cluster[order(cells.ord.cluster)]
regulon.scores <- t(aucell_regulonAUC.t[names(cells.ord.cluster),])
regulon.scores.log <- log(regulon.scores +1)
regulon.scores.scaled <- scale(regulon.scores)

library(gplots)
library(pheatmap)

# 进一步标化
cal_z_score <- function(x){
  (x - mean(x)) / sd(x)
}
data_subset_norm <- t(apply(regulon.scores, 1, cal_z_score))
#pheatmap(data_subset_norm)

cluster.col <- data.frame(fibro.scenic@active.ident, row.names = names(fibro.scenic@active.ident))
colnames(cluster.col) <- "group"


pheatmap::pheatmap(regulon.scores.scaled, cluster_rows = T,cluster_cols = F, annotation_col = cluster.col, show_colnames = F, fontsize_row=5)
pheatmap::pheatmap(data_subset_norm, cluster_rows = T,cluster_cols = F, annotation_col = cluster.col, show_colnames = F)


#Average Regulon Activity 平均调控活性
regulonAUC <- loadInt(scenicOptions, "aucell_regulonAUC")
regulonAUC <- regulonAUC[onlyNonDuplicatedExtended(rownames(regulonAUC)),]
regulonActivity_byCellType <- sapply(split(rownames(cellInfo), cellInfo$NMF_celltype),
                                     function(cells) rowMeans(getAUC(regulonAUC)[,cells]))
regulonActivity_byCellType_Scaled <- t(scale(t(regulonActivity_byCellType), center = T, scale=T))
library(ggplot2)
library(cowplot)
library(RColorBrewer)

coul <- colorRampPalette(rev(brewer.pal(9, "Spectral")))(100)
pheatmap::pheatmap(regulonActivity_byCellType_Scaled,cluster_cols = F,cluster_rows = F,color = coul)

dev.off()

##------------------------------------------------
# 亚组特异性专利因子
# Cell-type specific regulators (based on the Regulon Specificity Score (RSS) proposed by Suo et al. for the Mouse Cell Atlas in 2018). 
# Useful for big analysis with many cell types, to identify the cell-type specific regulons.
# regulonAUC <- loadInt(scenicOptions, "aucell_regulonAUC")
table(scRNAsub$NMF_celltype)
rss <- calcRSS(AUC=getAUC(regulonAUC), cellAnnotation=cellInfo[colnames(regulonAUC), "NMF_celltype"], )
rssPlot <- plotRSS(rss)
colnames(rss)
## Showing regulons and cell types with any RSS > 0.01 (dim: 6x5)
plotRSS_oneSet(rss, setName = "UBE2N+Epi-C1")


