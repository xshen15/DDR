###km
rt=read.table("expTime.txt", header=T, sep="\t", check.names=F, row.names=1) 
#读取输入文件
a=list.files('./k_m_TCGA_GEO/')
a=stringr::str_remove(a,pattern = '.pdf')


rt=rt[,c('futime','fustat',a)]




################
library(survival)
library(survminer)
library(rms)
multiCox=coxph(Surv(futime, fustat) ~ ., data = rt)
#逐步回归是选择性的
#multiCox=step(multiCox,direction = 'backward')
multiCoxSum=summary(multiCox)
save(multiCox,multiCoxSum,file ='multiCox_gene.Rdata')
load('multiCox_gene.Rdata')

p=ggforest(multiCox,data = rt,main ="Hazard ratio",
           cpositions = c(0.01,0.22,0.4),
           fontsize = 0.6,
           refLabel = "1", noDigits = 3)
p
#输出模型参数
outTab=data.frame()
outTab=cbind(
  coef=multiCoxSum$coefficients[,"coef"],
  HR=multiCoxSum$conf.int[,"exp(coef)"],
  HR.95L=multiCoxSum$conf.int[,"lower .95"],
  HR.95H=multiCoxSum$conf.int[,"upper .95"],
  pvalue=multiCoxSum$coefficients[,"Pr(>|z|)"])
outTab=cbind(id=row.names(outTab),outTab)
outTab=gsub("`","",outTab)
#write.table(outTab,file="multiCox_gene.xls",sep="\t",row.names=F,quote=F)


dev.off()
#输出病人风险值
#load('modelbase.Rdata')
#multicox——模型，risk——风险 ,newdata——需要地文件
riskScore=predict(multiCox,type="risk",newdata=rt)
coxGene=rownames(multiCoxSum$coefficients)
coxGene=gsub("`","",coxGene)
outCol=c("futime","fustat",coxGene)
risk=as.vector(ifelse(riskScore>median(riskScore),"high","low"))
write.table(cbind(id=rownames(cbind(rt[,outCol],riskScore,risk)),cbind(rt[,outCol],riskScore,risk)),
            file="risk.txt",
            sep="\t",
            quote=F,
            row.names=F)


library(survival)
library("survminer")
rt=read.table("risk.txt",header=T,sep="\t")

rt$risk=factor(rt$risk)
rt$risk=relevel(rt$risk,ref = 'low')
fit <- survfit(Surv(futime, fustat) ~ risk, data = rt)
#绘制生存曲线
#图片的高度
ggsurvplot(fit, 
           data=rt,
           pval = T,
           conf.int=F,
           pval.size=4,
           risk.table=F,
           legend=c(0.88,0.88),
           legend.labs=c("low", "high"),
           legend.title= "risk" ,
           xlab="Months",
           risk.table.title="",
           title='TCGA',
           palette = c("#8FC0DB","#FE1111"),
           risk.table.height=.25,
           font.title=12)
#绘制有CI的生存曲线

sfit <- survfit(Surv(futime, fustat)~risk, data=rt)

ggsurvplot(sfit,palette = c("#8FC0DB","#FE1111"),
           risk.table =TRUE,pval =TRUE,
           conf.int =TRUE,
           ggtheme =theme_light())

########################################################验证集
rt=read.table("expTime_GEO.txt", header=T, sep="\t", check.names=F, row.names=1)     #读取输入文件
a=list.files('./k_m_TCGA_GEO/')
a=stringr::str_remove(a,pattern = '.pdf')


rt=rt[,c('futime','fustat',a)]


################
#multicox——模型，risk——风险 ,newdata——需要地文件
riskScore=predict(multiCox,type="risk",newdata=rt)
coxGene=rownames(multiCoxSum$coefficients)
coxGene=gsub("`","",coxGene)
outCol=c("futime","fustat",coxGene)
risk=as.vector(ifelse(riskScore>median(riskScore),"high","low"))
write.table(cbind(id=rownames(cbind(rt[,outCol],riskScore,risk)),cbind(rt[,outCol],riskScore,risk)),
            file="risk_acrg.txt",
            sep="\t",
            quote=F,
            row.names=F)


library(survival)
library("survminer")
rt=read.table("risk_acrg.txt",header=T,sep="\t")

rt$risk=factor(rt$risk)
rt$risk=relevel(rt$risk,ref = 'low')
fit <- survfit(Surv(futime, fustat) ~ risk, data = rt)
#绘制生存曲线
#图片的高度
ggsurvplot(fit, 
           data=rt,
           pval = T,
           conf.int=F,
           pval.size=4,
           risk.table=F,
           legend=c(0.88,0.88),
           legend.labs=c("low", "high"),
           legend.title= "risk" ,
           xlab="Months",
           risk.table.title="",
           title='ACRG',
           palette =c("#8FC0DB","#FE1111"),
           risk.table.height=.25,
           font.title=12)
#绘制有CI的生存曲线

sfit <- survfit(Surv(futime, fustat)~risk, data=rt)

ggsurvplot(sfit,palette = c("#8FC0DB","#FE1111"),
           risk.table =TRUE,pval =TRUE,
           conf.int =TRUE,
           ggtheme =theme_light())
