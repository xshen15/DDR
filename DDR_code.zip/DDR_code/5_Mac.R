gc()
getwd()
scRNA=readRDS('scRNA_celltype.rds')
library(Seurat)
DimPlot(scRNA,split.by = 'orig.ident',reduction = 'tsne')

# 巨噬细胞的NMF和分析
scRNA_myelo=subset(scRNA,celltype %in% 'Monoctyes')

dim(scRNA_myelo)

## 重新聚类分群
scRNA_myelo<- ScaleData(scRNA_myelo)

scRNA_myelo<- RunPCA(scRNA_myelo) 
plot1 <- DimPlot(scRNA_myelo, reduction = "pca", group.by="orig.ident") 
plot2 <- ElbowPlot(scRNA_myelo, ndims=20, reduction="pca") 
plotc <- plot1+plot2
plotc

#PC选取比较随意
pc.num=1:10

scRNA_myelo <- FindNeighbors(scRNA_myelo, dims = pc.num) 

scRNA_myelo <- FindClusters(scRNA_myelo)
table(scRNA_myelo@meta.data$seurat_clusters)

#tSNE可视化
scRNA_myelo = RunTSNE(scRNA_myelo, dims = pc.num)
DimPlot(scRNA_myelo, reduction = "tsne",label = T) 

#UMAP可视化
scRNA_myelo <- RunUMAP(scRNA_myelo, dims = pc.num)
DimPlot(scRNA_myelo, reduction = "umap",label=T) 

habermann_imm <- c( "LYZ", "CD68", "ITGAX", "MARCO", "FCGR1A", "FCGR3A", "C1QA", "APOC1", "S100A12", "FCN1", "S100A9", "CD14", "FCER1A", "CD1C", "CD16", "CLEC9A", "LILRA4", "CLEC4C",
                    "CPA3",'GATA3', "KIT", "MKI67", "CDK1")
## 可以看到1，2是巨噬细胞，0是肥大细胞，3是单核细胞
library(ggplot2)
DotPlot(scRNA_myelo, features = habermann_imm,group.by = "seurat_clusters") +
  coord_flip()+scale_colour_gradientn(colours =c('#dadada','#bc3c29'))

## 
Myeloid_subtype <- read.csv('Monocyte_subtype.csv',header = F)$V2

Idents(scRNA_myelo) <- scRNA_myelo@meta.data$seurat_clusters
names(Myeloid_subtype) <- levels(scRNA_myelo)
scRNA_myelo<- RenameIdents(scRNA_myelo, Myeloid_subtype)

scRNA_myelo@meta.data$Myeloid_subtype <- Idents(scRNA_myelo)

Idents(scRNA_myelo)=scRNA_myelo@meta.data$Myeloid_subtype

DimPlot(scRNA_myelo, label = T,cols=c('#313c63','#b42e20','#ebc03e','#377b4c',
                                  '#7bc7cd','#5d84a4','#dadada'),
        reduction = 'tsne') 



## 取出肿瘤
scRNA_myelo=subset(scRNA_myelo,orig.ident %in% 'Tumor')
## 取出mac
scRNA_mac=subset(scRNA_myelo,Myeloid_subtype %in% 'Mac')


gene=read.csv('384DDR_gene.csv',header = F)
gene=as.matrix(gene)
gene=as.vector(gene)


# DDR
scRNA_mac$id=colnames(scRNA_mac)
scRNA_mac_aa=scRNA_mac[rownames(scRNA_mac) %in% gene,]

df <- scRNA_mac_aa@assays$RNA@data
df=as.data.frame(df)

df <- df[rowMeans(df) !=0,  ]
df <- df[,colMeans(df) !=0 ]

## 一点没表达的细胞去除
scRNA_mac=subset(scRNA_mac,id %in% colnames(df))

# nmf
library(NMF)
res <- nmf(df, 10, method = "snmf/r", seed = 'nndsvd')

## NMF结果返回suerat对象
scRNA_mac@reductions$nmf <- scRNA_mac@reductions$pca
scRNA_mac@reductions$nmf@cell.embeddings <- t(coef(res))    
scRNA_mac@reductions$nmf@feature.loadings <- basis(res)  

## 使用nmf的分解结果降维聚类!重要
set.seed(999)

scRNA_mac.nmf <- RunUMAP(scRNA_mac, reduction = 'nmf', dims = 1:10) 
scRNA_mac.nmf <- FindNeighbors(scRNA_mac.nmf,reduction = 'nmf', dims = 1:10)
scRNA_mac.nmf <- FindClusters(scRNA_mac.nmf)
scRNA_mac.nmf$NMF_cluster=scRNA_mac.nmf$seurat_clusters

## 结果可视化  
DimPlot(scRNA_mac.nmf, label = T,cols=c('#313c63','#b42e20','#ebc03e','#377b4c',
                                      '#7bc7cd','#5d84a4','#dadada')) 

df=FindAllMarkers(scRNA_mac.nmf,logfc.threshold = 0.5,only.pos = T)
sss=intersect(df$gene,gene)
write.csv(df,file ='deg_mac.csv',quote=F)

# test some genes
FeaturePlot(scRNA_mac.nmf,features = 'VCP',label = T)
DoHeatmap(scRNA_mac.nmf,features = rownames(df),assay = 'RNA',slot = 'count')


## 拟时序分析
library(Seurat)
#没有monocle要先安装 BiocManager::install()
#BiocManager::install('monocle',update = F,ask = F)

library(BiocGenerics)
library(monocle)
library(tidyverse)
library(patchwork)
data=as.matrix(scRNA_mac.nmf@assays$RNA@counts)

data <- as(data, 'sparseMatrix')
pd <- new('AnnotatedDataFrame', data = scRNA_mac.nmf@meta.data)
fData <- data.frame(gene_short_name = row.names(data), row.names = row.names(data))
fd <- new('AnnotatedDataFrame', data = fData)
## 以下代码一律不得修改
mycds <- newCellDataSet(data,
                        phenoData = pd,
                        featureData = fd,
                        expressionFamily = negbinomial.size())

mycds <- estimateSizeFactors(mycds)
mycds <- estimateDispersions(mycds, cores=4, relative_expr = TRUE)

##使用monocle选择的高变基因，不修改
disp_table <- dispersionTable(mycds)
disp.genes <- subset(disp_table, mean_expression >= 0.1 & dispersion_empirical >= 1 * dispersion_fit)$gene_id
mycds <- setOrderingFilter(mycds, disp.genes)
plot_ordering_genes(mycds)

#降维
mycds <- reduceDimension(mycds, max_components = 2, method = 'DDRTree')
#排序
mycds <- orderCells(mycds)

ss=intersect(gene,rownames(scRNA_mac.nmf))
dev.off()
my_pseudotime_cluster <- plot_pseudotime_heatmap(mycds[ss,],
                                                 # num_clusters = 2, # add_annotation_col = ac,
                                                 show_rownames = TRUE,
                                                 return_heatmap = TRUE)

my_pseudotime_cluster 


#State轨迹分布图
plot1 <- plot_cell_trajectory(mycds, color_by = "State")
plot1

plot4 <- plot_cell_trajectory(mycds, color_by = "NMF_cluster")
plot4

##合并出图
plotc <- plot1|plot4
plotc


## 定义新的细胞亚群！注意修改代码！！！！！！！！！！！！！！
NMF_celltype <- c('POLR2A+Mac-C1','UBE2N+Mac-C2','RAD23A+Mac-C3',
                  'HMGB2+Mac-C4','PER1+Mac-C5','CDK4+Mac-C6',
                  'Non-DDR-Mac-C7','TDG+Mac-C8','SMUG1+Mac-C9',
                  'POLR2E+Mac-C10','HMGB1+Mac-C11')

Idents(scRNA_mac.nmf) <- scRNA_mac.nmf@meta.data$NMF_cluster
names(NMF_celltype) <- levels(scRNA_mac.nmf)
scRNA_mac.nmf<- RenameIdents(scRNA_mac.nmf, NMF_celltype)

scRNA_mac.nmf@meta.data$NMF_celltype <- Idents(scRNA_mac.nmf)

Idents(scRNA_mac.nmf)=scRNA_mac.nmf@meta.data$NMF_celltype

DimPlot(scRNA_mac.nmf,group.by = 'NMF_celltype',
        cols=c('#313c63','#b42e20','#ebc03e','#377b4c',
               '#7bc7cd','#5d84a4','#313c63','#b42e20',
               '#ebc03e','#377b4c','#7bc7cd'),
        label = T,label.size = 3)

saveRDS(scRNA_mac.nmf,file ='scRNA_mac_NMF.RDS')

########## 细胞通讯(巨噬细胞和上皮）#################################
scRNA_mac.nmf=readRDS('scRNA_mac_NMF.RDS')
scRNA_chat <-subset(scRNA, orig.ident =='Tumor')
table(scRNA@meta.data$celltype)
scRNA_chat2 <-subset(scRNA_chat, idents=c('Undetermined','Monoctyes'),invert=T)
table(scRNA_chat2@meta.data$celltype)

# 赋一列
scRNA_chat2$NMF_celltype=scRNA_chat2$celltype
scRNA_chat=merge(scRNA_chat2,scRNA_mac.nmf)


meta =scRNA_chat@meta.data # a dataframe with rownames containing cell mata data

data_input <- as.matrix(scRNA_chat@assays$RNA@data)
#data_input=data_input[,rownames(meta)]
identical(colnames(data_input),rownames(meta))

library(CellChat)
cellchat <- createCellChat(object = data_input, meta = meta, group.by = "NMF_celltype")

CellChatDB <- CellChatDB.human 
groupSize <- as.numeric(table(cellchat@idents))
CellChatDB.use <- subsetDB(CellChatDB, search = "Secreted Signaling") 
cellchat@DB <- CellChatDB.use 

dplyr::glimpse(CellChatDB$interaction)##配体-受体分析
# 提取数据库支持的数据子集
cellchat <- subsetData(cellchat)
# 识别过表达基因
cellchat <- identifyOverExpressedGenes(cellchat)
# 识别配体-受体对
cellchat <- identifyOverExpressedInteractions(cellchat)
# 将配体、受体投射到PPI网络
cellchat <- projectData(cellchat, PPI.human)
unique(cellchat@idents)

cellchat <- computeCommunProb(cellchat)

# Filter out the cell-cell communication if there are only few number of cells in certain cell groups
cellchat <- filterCommunication(cellchat, min.cells = 10)
cellchat <- computeCommunProbPathway(cellchat)

df.net<- subsetCommunication(cellchat)

cellchat <- aggregateNet(cellchat)
groupSize <- as.numeric(table(cellchat@idents))

##时常deff.off!!!!
dev.off()
table(meta$celltype)
netVisual_circle(cellchat@net$count, vertex.weight = groupSize, 
                 weight.scale = T, label.edge= T,
                 sources.use = c('POLR2A+Mac-C1','UBE2N+Mac-C2','RAD23A+Mac-C3',
                                 'HMGB2+Mac-C4','PER1+Mac-C5','CDK4+Mac-C6',
                                 'Non-DDR-Mac-C7','TDG+Mac-C8','SMUG1+Mac-C9',
                                 'POLR2E+Mac-C10','HMGB1+Mac-C11'), 
                 targets.use = c('Epithelial cells','B cells','Endothelial',
                                 'Mast_cells','Fibroblasts','T cells'),
                 title.name = "Number of interactions")
dev.off()

netVisual_circle(cellchat@net$weight, vertex.weight = groupSize, 
                 weight.scale = T, label.edge= T, 
                 sources.use = c('POLR2A+Mac-C1','UBE2N+Mac-C2','RAD23A+Mac-C3',
                                 'HMGB2+Mac-C4','PER1+Mac-C5','CDK4+Mac-C6',
                                 'Non-DDR-Mac-C7','TDG+Mac-C8','SMUG1+Mac-C9',
                                 'POLR2E+Mac-C10','HMGB1+Mac-C11'), 
                 targets.use = c('Epithelial cells','B cells','Endothelial',
                                 'Mast_cells','Fibroblasts','T cells'),
                 title.name = "Interaction weights/strength")

#bubble图
dev.off()
netVisual_bubble(cellchat, 
                 sources.use = c('POLR2A+Mac-C1','UBE2N+Mac-C2','RAD23A+Mac-C3',
                                 'HMGB2+Mac-C4','PER1+Mac-C5','CDK4+Mac-C6',
                                 'Non-DDR-Mac-C7','TDG+Mac-C8','SMUG1+Mac-C9',
                                 'POLR2E+Mac-C10','HMGB1+Mac-C11'), 
                 targets.use = c('Epithelial cells','B cells','Endothelial',
                                 'Mast_cells','Fibroblasts','T cells'), 
                 remove.isolate = FALSE) 
cellchat <- netAnalysis_computeCentrality(cellchat, slot.name = "netP")


h1=netAnalysis_signalingRole_heatmap(cellchat, pattern = "outgoing")
h2=netAnalysis_signalingRole_heatmap(cellchat, pattern = "incoming")
h1 + h2


#### scMetabolism
#devtools::install_github("YosefLab/VISION")
#install.packages('wesanderson')
#library(wesanderson)
#devtools::install_github("wu-yc/scMetabolism")

library(scMetabolism)
library(ggplot2)
library(rsvd)
scRNA_mac.nmf_meta<-sc.metabolism.Seurat(obj = scRNA_mac.nmf, method = "VISION", imputation = F, ncores = 2, metabolism.type = "KEGG")

input.pathway <- rownames(scRNA_mac.nmf_meta@assays[["METABOLISM"]][["score"]])[1:30]
DotPlot.metabolism(obj = scRNA_mac.nmf_meta,
                   pathway = input.pathway, phenotype = "NMF_celltype", norm = "y")
                   
### 转录因子
#####SCENIC#####
scRNAsub=readRDS('scRNA_mac_NMF.RDS')

library(SCENIC)
library(Seurat)

## 内存不够控制细胞数目,这里CAF只有100多个，所以不挑
#set.seed(123456)
#a=sample(1:ncol(scRNAsub),200)
#scRNAsub=scRNAsub[,a]

exprMat <- as.matrix(scRNAsub@assays$RNA@counts)
cellInfo <-scRNAsub@meta.data

# 进入子文件夹
setwd("SCENIC") 
getwd()
Idents(scRNAsub)=scRNAsub$NMF_celltype

### Initialize settings
dir.create("int")
saveRDS(cellInfo, file="int/cellInfo.Rds")

Idents(scRNAsub) <- "NMF_cluster"
# Color to assign to the variables (same format as for NMF::aheatmap)

# 人！！！！
org='hgnc'


dbDir="D:/single_cell_project/HRD/CRC_HRD/SCENIC/SCENIC2" # RcisTarget databases location

myDatasetTitle="SCENIC Challenge" # choose a name for your analysis
data(defaultDbNames)
dbs <- defaultDbNames[[org]]
dbs
getwd()
scenicOptions <- initializeScenic(org=org,dbDir=dbDir,dbs=dbs)

scenicOptions@inputDatasetInfo$cellInfo <- "cellInfo.Rds"
scenicOptions@inputDatasetInfo$colVars <- "colVars.Rds"

# 节省内存，我们只取一个基因组文件
# 人：用下面！！！！！！！！！
scenicOptions@settings$dbs <- c("mm9-5kb-mc8nr" = "hg19-tss-centered-10kb-7species.mc9nr.feather")
scenicOptions@settings$db_mcVersion <- "v8"
saveRDS(scenicOptions, file="scenicOptions.Rds") 

#Gene filter: Filter by the number of cells in which the gene is detected (minCountsPerGene, by default 6 UMI counts across all samples)
# and by the number of cells in which the gene is detected (minSamples, by default 1% of the cells)
# 尽可能减少基因数目
# 如果需要更多基因，0.1调成0.05或0.01
genesKept <- geneFiltering(exprMat, scenicOptions=scenicOptions,minCountsPerGene=3*.01*ncol(exprMat),minSamples=ncol(exprMat)*.4)
exprMat_filtered <- exprMat[genesKept,]
dim(exprMat_filtered)

#calculating correlation
runCorrelation(exprMat_filtered, scenicOptions)

#GENIE3: infer potential transcription factor targets based on the expression data
exprMat_filtered <- log2(exprMat_filtered+1) 


# 等待较久的一步，纳入基因和细胞越多，等待越久，此处只用了1000多基因，200个细胞
# 对应的TF也只有100多个了，其实有1000多个TF，如果是性能好的计算机可以考虑前面0.1调成0.05或0.01
library(RcisTarget)
data(motifAnnotations_hgnc_v8) 

runGenie3(exprMat_filtered, scenicOptions)

scenicOptions@settings$verbose <- TRUE
scenicOptions@settings$nCores <- 1
scenicOptions@settings$seed <- 123


exprMat_log <- log2(exprMat+1)
dim(exprMat)

#scenicOptions@settings$dbs <- scenicOptions@settings$dbs["10kb"] # For toy run
scenicOptions <- runSCENIC_1_coexNetwork2modules(scenicOptions)
saveRDS(scenicOptions, file="scenicOptions.Rds") 

# step2容易崩，节省内存只看top50
gc()
getwd()
scenicOptions=readRDS('scenicOptions.Rds')

library(RcisTarget)
data(motifAnnotations_hgnc) 
scenicOptions <-runSCENIC_2_createRegulons(scenicOptions, coexMethod=c("top5perTarget"))#** Only for toy run!!
#scenicOptions <- runSCENIC_2_createRegulons(scenicOptions) 
saveRDS(scenicOptions, file="scenicOptions.Rds")

library(foreach)
scenicOptions <- readRDS("scenicOptions.Rds")
scenicOptions <- runSCENIC_3_scoreCells(scenicOptions, exprMat_log)
saveRDS(scenicOptions, file="scenicOptions_mac.Rds") # To save status

#============================================

#下次可以直接读取他,我们已经越过最耗时间的步骤
# 如果经常报错，不要重新readRDS和load，应不间断运行

scenicOptions <- readRDS("scenicOptions_mac.Rds")
scenicOptions@settings$seed <- 123 # same seed for all of them

#Binarizing the network

runSCENIC_4_aucell_binarize(scenicOptions)

aucell_regulonAUC <- loadInt(scenicOptions, "aucell_regulonAUC")
aucell_regulonAUC
aucell_regulonAUC.t <- t(aucell_regulonAUC@assays@data$AUC)
colnames(aucell_regulonAUC.t) <- gsub(" ", "_", colnames(aucell_regulonAUC.t))
rownames(aucell_regulonAUC.t) <- gsub("[.]", "-", rownames(aucell_regulonAUC.t))

fibro.scenic <- scRNAsub
# 结果导入endo.scenic
fibro.scenic@meta.data <- cbind(fibro.scenic@meta.data, aucell_regulonAUC.t[rownames(fibro.scenic@meta.data),])
dev.off()
DimPlot(fibro.scenic, reduction = "umap")
# 找6个
FeaturePlot(fibro.scenic, reduction = "umap", features = colnames(fibro.scenic@meta.data)[20:27], cols = c("yellow", "red"))

#Regulon scores heatmap 热图
Idents(fibro.scenic)=fibro.scenic$NMF_celltype
cells.ord.cluster <- fibro.scenic@active.ident
cells.ord.cluster<- cells.ord.cluster[order(cells.ord.cluster)]
regulon.scores <- t(aucell_regulonAUC.t[names(cells.ord.cluster),])
regulon.scores.log <- log(regulon.scores +1)
regulon.scores.scaled <- scale(regulon.scores)

library(gplots)
library(pheatmap)

# 进一步标化
cal_z_score <- function(x){
  (x - mean(x)) / sd(x)
}
data_subset_norm <- t(apply(regulon.scores, 1, cal_z_score))
#pheatmap(data_subset_norm)

cluster.col <- data.frame(fibro.scenic@active.ident, row.names = names(fibro.scenic@active.ident))
colnames(cluster.col) <- "group"


pheatmap::pheatmap(regulon.scores.scaled, cluster_rows = T,cluster_cols = F, annotation_col = cluster.col, show_colnames = F, fontsize_row=5)
pheatmap::pheatmap(data_subset_norm, cluster_rows = T,cluster_cols = F, annotation_col = cluster.col, show_colnames = F)


#Average Regulon Activity 平均调控活性
regulonAUC <- loadInt(scenicOptions, "aucell_regulonAUC")
regulonAUC <- regulonAUC[onlyNonDuplicatedExtended(rownames(regulonAUC)),]
library(AUCell)
regulonActivity_byCellType <- sapply(split(rownames(cellInfo), cellInfo$NMF_celltype),
                                     function(cells) rowMeans(getAUC(regulonAUC)[,cells]))
regulonActivity_byCellType_Scaled <- t(scale(t(regulonActivity_byCellType), center = T, scale=T))
library(ggplot2)
library(cowplot)
library(RColorBrewer)
coul <- colorRampPalette(rev(brewer.pal(9, "Spectral")))(100)
pheatmap::pheatmap(regulonActivity_byCellType_Scaled,cluster_cols = F,cluster_rows = F,color = coul)

dev.off()

##------------------------------------------------
# 亚组特异性专利因子
# Cell-type specific regulators (based on the Regulon Specificity Score (RSS) proposed by Suo et al. for the Mouse Cell Atlas in 2018). 
# Useful for big analysis with many cell types, to identify the cell-type specific regulons.
# regulonAUC <- loadInt(scenicOptions, "aucell_regulonAUC")
table(scRNAsub$NMF_celltype)
rss <- calcRSS(AUC=getAUC(regulonAUC), cellAnnotation=cellInfo[colnames(regulonAUC), "NMF_celltype"], )
rssPlot <- plotRSS(rss)
## Showing regulons and cell types with any RSS > 0.01 (dim: 6x5)
plotRSS_oneSet(rss, setName = "PER1+Mac-C5")



###M1,M2亚型比较
scRNA_mac.nmf=readRDS('scRNA_mac_NMF.RDS')
library(dplyr)
library(readr)
library(stringr)
m1m2_pws <- read_lines("CLASSICAL_M1_VS_ALTERNATIVE_M2_MACROPHAGE_UP.gmt") %>%
  lapply(str_split, "\\t") %>% 
  unlist(recursive = F) %>% 
  lapply(function(x) setNames(list(x[-c(1:2)]), x[1])) %>% 
  unlist(recursive = F)

### M2
m1m2_pws <- append(m1m2_pws, read_lines("CLASSICAL_M1_VS_ALTERNATIVE_M2_MACROPHAGE_DN.gmt") %>%
                     lapply(str_split, "\\t") %>% 
                     unlist(recursive = F) %>% 
                     lapply(function(x) setNames(list(x[-c(1:2)]), x[1])) %>% 
                     unlist(recursive = F))

save(m1m2_pws,file ='m1m2.Rdata')
load('m1m2.Rdata')

library(Seurat)
scRNA_mac.nmf<- AddModuleScore(object = scRNA_mac.nmf, 
                               features = m1m2_pws, name = c("m1up", "m1dn"), nbin = 12)


VlnPlot(scRNA_mac.nmf, features = c("m1up1", "m1dn2"), 
        group.by = "NMF_celltype", cols=c('#313c63','#b42e20','#ebc03e','#377b4c',
                                          '#7bc7cd','#5d84a4','#313c63','#b42e20',
                                          '#ebc03e','#377b4c','#7bc7cd'))

library(viridis)
FeaturePlot(scRNA_mac.nmf,features = c("m1up1",'m1dn2'),label = T,cols = magma(10))
## 注意选择列
colnames(scRNA_mac.nmf@meta.data)
df=scRNA_mac.nmf@meta.data[,c(18:20)]
a=aggregate(df[,2:3],list(df$NMF_celltype),mean)
rownames(a)=a$Group.1
a$Group.1=NULL
library(pheatmap)
library(RColorBrewer)
coul <- colorRampPalette(rev(brewer.pal(9, "Spectral")))(100)
pheatmap(a,scale='column',color = coul,)

