setwd('e:/work/oncofetal/')

#BiocManager::install('Seurat',update=F)
library(Seurat)

files=list.files(pattern = '.txt')
filelent <- length(files)
files
temp1 <- read.table(files[1],header = T,row.names = 1,check.names = F)
temp2 <- read.table(files[2],header = T,row.names = 1,check.names = F)
temp3 <- read.table(files[3],header = T,row.names = 1,check.names = F)

library(Seurat)

scRNA1 <- CreateSeuratObject(counts = temp1,project = "Normal1")
scRNA2 <- CreateSeuratObject(counts = temp2,project = "Tumor1")
scRNA3 <- CreateSeuratObject(counts = temp3,project = "Tumor2")


### 合并scRNA1,scRNA2,scRNA3
## 没有正常样本则不加scRNA1
### 更多样本可以自行加入
#scRNA <- merge(scRNA1, y = c(scRNA2,scRNA3))
scRNA <- merge(scRNA1,y=c(scRNA2, scRNA3))

# metadata为样本信息，我们需要定义分组
scRNA@meta.data$tissue_type=scRNA@meta.data$orig.ident
#install.packages('stringr')
# 去除数字
scRNA@meta.data$tissue_type=stringr::str_remove(scRNA@meta.data$tissue_type,'[0-9]')

# 质控
##计算质控指标
#计算细胞中线粒体核糖体基因比例
scRNA[["percent.mt"]] <- PercentageFeatureSet(scRNA, pattern = "^MT-")
#计算红细胞比例
HB.genes <- c("HBA1","HBA2","HBB","HBD","HBE1","HBG1","HBG2","HBM","HBQ1","HBZ")
HB_m <- match(HB.genes, rownames(scRNA@assays$RNA)) 
HB.genes <- rownames(scRNA@assays$RNA)[HB_m] 
HB.genes <- HB.genes[!is.na(HB.genes)] 
scRNA[["percent.HB"]]<-PercentageFeatureSet(scRNA, features=HB.genes) 
#head(scRNA@meta.data)
library(ggplot2)
col.num <- length(levels(scRNA@active.ident))
# 过滤前
VlnPlot(scRNA,features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.HB"), 
                  cols =rainbow(col.num), 
                  pt.size = 0.01, #不需要显示点，可以设置pt.size = 0
                  ncol = 4) + 
  theme(axis.title.x=element_blank(), axis.text.x=element_blank(), axis.ticks.x=element_blank()) 

plot1 <- FeatureScatter(scRNA, feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(scRNA, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot3 <- FeatureScatter(scRNA, feature1 = "nCount_RNA", feature2 = "percent.HB")
pearplot <- CombinePlots(plots = list(plot1, plot2, plot3), nrow=1, legend="none") 
pearplot

##设置质控标准，比较随意
print(c("请输入允许基因数和核糖体比例，示例如下：", "minGene=500", "maxGene=4000", "pctMT=20"))
minGene=200
maxGene=10000
pctMT=15

##数据质控
scRNA <- subset(scRNA, subset = nFeature_RNA > minGene & nFeature_RNA < maxGene & percent.mt < pctMT)
col.num <- length(levels(scRNA@active.ident))
VlnPlot(scRNA,
                 features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.HB"), 
                 cols =rainbow(col.num), 
                 pt.size = 0.1, 
                 ncol = 4) + 
  theme(axis.title.x=element_blank(), axis.text.x=element_blank(), axis.ticks.x=element_blank()) 

# 标准化
scRNA <- NormalizeData(scRNA, normalization.method = "LogNormalize", scale.factor = 10000)

#降维聚类#########################
library(Seurat)
library(tidyverse)
library(patchwork)

scRNA <- FindVariableFeatures(scRNA, selection.method = "vst", nfeatures = 2000) 
top10 <- head(VariableFeatures(scRNA), 10) 
plot1 <- VariableFeaturePlot(scRNA) 
plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE, size=2.5) 
plot <- CombinePlots(plots = list(plot1, plot2),legend="bottom") 
plot

#只对高变基因进行scale
scale.genes <-  VariableFeatures(scRNA)
scRNA <- ScaleData(scRNA, features = scale.genes)


scRNA <- RunPCA(scRNA, features = VariableFeatures(scRNA)) 
plot1 <- DimPlot(scRNA, reduction = "pca", group.by="orig.ident") 
plot2 <- ElbowPlot(scRNA, ndims=20, reduction="pca") 
plotc <- plot1+plot2
plotc


#PC选取比较随意
pc.num=1:10

scRNA <- FindNeighbors(scRNA, dims = pc.num) 

scRNA <- FindClusters(scRNA)
table(scRNA@meta.data$seurat_clusters)
metadata <- scRNA@meta.data
cell_cluster <- data.frame(cell_ID=rownames(metadata), cluster_ID=metadata$seurat_clusters)

#tSNE可视化
scRNA = RunTSNE(scRNA, dims = pc.num)
plot1 = DimPlot(scRNA, reduction = "tsne",label = T) 
plot1

#UMAP可视化
scRNA <- RunUMAP(scRNA, dims = pc.num)
plot2 = DimPlot(scRNA, reduction = "umap",label=T) 
plot2

#合并tSNE与UMAP
plotc <- plot1+plot2+ plot_layout(guides = 'collect')
plotc



###鉴定细胞类型
###3.细胞类型鉴定
# 
habermann_imm <- c('CD274',"CD3E", "CD4", "FOXP3", "IL7R", "IL2RA", "CD40LG", "CD8A", "CCL5", "NCR1", "KLRB1", "NKG7", "LYZ", "CD68", "ITGAX", "MARCO", "FCGR1A", "FCGR3A", "C1QA", "APOC1", "S100A12", "FCN1", "S100A9", "CD14", "FCER1A", "CD1C", "CD16", "CLEC9A", "LILRA4", "CLEC4C", "JCHAIN", "IGHG1", "IGLL5", "MS4A1", "CD19", "CD79A", "CPA3",'GATA3', "KIT", "MKI67", "CDK1", "EPCAM")

habermann_oth <- c("VWF", "PECAM1", "CCL21", "PROX1", "ACTA2", "MYH11", "PDGFRB", "WT1", "UPK3B", "LUM", "PDGFRA", "MYLK", "HAS1", "PLIN2", "FAP", "PTPRC", "EPCAM")

DotPlot(scRNA, features = habermann_imm,group.by = "seurat_clusters") + coord_flip()
DotPlot(scRNA, features = habermann_oth,group.by = "seurat_clusters") + coord_flip()

### 注释

## 
celltype <- c('B_cells','T_cells','Epithelial_cells','T_cells','Endothelial_cells',
              'B_cells','Fibroblasts','Endothelial_cells','Myeloids',
              'Epithelial_cells','B_cells','Epithelial_cells','Epithelial_cells')

Idents(scRNA) <- scRNA@meta.data$seurat_clusters
names(celltype) <- levels(scRNA)
scRNA<- RenameIdents(scRNA, celltype)

scRNA@meta.data$celltype <- Idents(scRNA)

Idents(scRNA)=scRNA@meta.data$celltype

colors=c('#313c63','#b42e20','#ebc03e','#377b4c',
         '#7bc7cd','#5d84a4')
p1 = DimPlot(scRNA, group.by="celltype", label=T, label.size=5, reduction='tsne',pt.size = 1,cols = colors)
p1
p2 = DimPlot(scRNA, group.by="celltype", label=T, label.size=5, reduction='umap',pt.size = 1,cols = colors)
p2
p3 = plotc <- p1+p2+ plot_layout(guides = 'collect')
p3
FeaturePlot(scRNA,features = 'TUBA1A',split.by = 'orig.ident',label=T)
saveRDS(scRNA,file ='scRNA_anno.rds')

scRNA=readRDS('scRNA_anno.rds')
#########细胞通讯全局分析
# 先安装cellchat
library(CellChat)
# 选取第一个样本，如果内存不够，再进一步减少细胞数，例如随机抽1000个
# 内存够，则不挑选直接上
#scRNA_chat <- subset(scRNA, orig.ident=='Tumor1')
scRNA_chat <-subset(scRNA, tissue_type =='Tumor')

meta =scRNA_chat@meta.data # a dataframe with rownames containing cell mata data

data_input <- as.matrix(scRNA_chat@assays$RNA@data)
#data_input=data_input[,rownames(meta)]
identical(colnames(data_input),rownames(meta))

library(CellChat)
cellchat <- createCellChat(object = data_input, meta = meta, group.by = "celltype")

CellChatDB <- CellChatDB.human 
groupSize <- as.numeric(table(cellchat@idents))
CellChatDB.use <- subsetDB(CellChatDB, search = "Secreted Signaling") 
cellchat@DB <- CellChatDB.use 

dplyr::glimpse(CellChatDB$interaction)##配体-受体分析
# 提取数据库支持的数据子集
cellchat <- subsetData(cellchat)
# 识别过表达基因
cellchat <- identifyOverExpressedGenes(cellchat)
# 识别配体-受体对
cellchat <- identifyOverExpressedInteractions(cellchat)
# 将配体、受体投射到PPI网络
cellchat <- projectData(cellchat, PPI.human)
unique(cellchat@idents)

cellchat <- computeCommunProb(cellchat)

# Filter out the cell-cell communication if there are only few number of cells in certain cell groups
cellchat <- filterCommunication(cellchat, min.cells = 10)
cellchat <- computeCommunProbPathway(cellchat)

df.net<- subsetCommunication(cellchat)

write.csv(df.net,file ='cellchat.csv',quote=F)
#returns a data frame consisting of all the inferred cell-cell communications at the level of ligands/receptors. Set slot.name = "netP" to access the the inferred communications at the level of signaling pathways

#df.net <- subsetCommunication(cellchat, sources.use = c(1,2), targets.use = c(4,5)) 
#gives the inferred cell-cell communications sending from cell groups 1 and 2 to cell groups 4 and 5.

#df.net <- subsetCommunication(cellchat, signaling = c("WNT", "TGFb")) 

cellchat <- aggregateNet(cellchat)
groupSize <- as.numeric(table(cellchat@idents))
dev.off()
netVisual_circle(cellchat@net$count, vertex.weight = groupSize, weight.scale = T, label.edge= T, title.name = "Number of interactions")
dev.off()

#####------------------------
# 关键热图

library(Seurat)
gene=read.table('E:/work/stem/REACTOME_TRANSCRIPTIONAL_REGULATION_OF_PLURIPOTENT_STEM_CELLS.v2022.1.Hs.gmt')
gene=gene[,3:33]
gene=t(gene)
DoHeatmap(subset(scRNA,downsample=50,),features = gene,group.by = 'celltype',assay='RNA',slot = 'data',
          group.colors =c('#313c63','#b42e20','#ebc03e','#377b4c',
                     '#7bc7cd','#5d84a4'),lines.width = 10)+
  scale_fill_gradientn(colors=c('white','firebrick3'),na.value = 'white')
metadata=scRNA@meta.data


VlnPlot(scRNA,features = gene[9:12])
VlnPlot(scRNA,features = 'CDC34')
FeaturePlot(scRNA,features = 'TUBB6',reduction = 'tsne',pt.size = 1)


